document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');

    // CREATE POPUP
    const popup = document.createElement('div');
    popup.id = 'success-popup';
    popup.style.position = 'fixed';
    popup.style.top = '50%';
    popup.style.left = '50%';
    popup.style.transform = 'translate(-50%, -50%) scale(0)';
    popup.style.padding = '30px 45px';
    popup.style.background = 'linear-gradient(135deg, #6a11cb, #2575fc, #ffb703)';
    popup.style.color = 'white';
    popup.style.fontSize = '1rem';
    popup.style.fontWeight = '700';
    popup.style.borderRadius = '25px';
    popup.style.boxShadow = '0 15px 40px rgba(37,117,252,0.4)';
    popup.style.textAlign = 'center';
    popup.style.whiteSpace = 'pre-line';
    popup.style.transition = 'transform 0.5s ease, opacity 0.5s ease';
    popup.style.zIndex = '9999';
    popup.style.opacity = '0';
    document.body.appendChild(popup);

    // CREATE LOADER
    const loader = document.createElement('div');
    loader.id = 'form-loader';
    loader.style.position = 'fixed';
    loader.style.top = '0';
    loader.style.left = '0';
    loader.style.width = '100%';
    loader.style.height = '100%';
    loader.style.background = 'rgba(0,0,0,0.35)';
    loader.style.display = 'flex';
    loader.style.alignItems = 'center';
    loader.style.justifyContent = 'center';
    loader.style.zIndex = '9998';
    loader.style.opacity = '0';
    loader.style.transition = 'opacity 0.3s ease';
    document.body.appendChild(loader);

    const spinner = document.createElement('div');
    spinner.style.border = '6px solid #f3f3f3';
    spinner.style.borderTop = '6px solid #6a11cb';
    spinner.style.borderRadius = '50%';
    spinner.style.width = '50px';
    spinner.style.height = '50px';
    spinner.style.animation = 'spin 1s linear infinite';
    loader.appendChild(spinner);

    const style = document.createElement('style');
    style.innerHTML = `
        @keyframes spin { 0% { transform: rotate(0deg);} 100% { transform: rotate(360deg);} }
    `;
    document.head.appendChild(style);

    // FORM SUBMIT
    form.addEventListener('submit', function (e) {
        e.preventDefault();

        try {
            let valid = true;
            form.querySelectorAll('[required]').forEach(input => {
                if (!input.value) {
                    input.style.borderColor = 'red';
                    valid = false;
                } else {
                    input.style.borderColor = '#ddd';
                }
            });
            if (!valid) return;

            loader.style.opacity = '1';

            setTimeout(() => {
                loader.style.opacity = '0';

                // Collect info
                const formData = new FormData(form);
                let infoText = "Registration Successful! 🎉\n\n";
                for (const [key, value] of formData.entries()) {
                    if (value) infoText += `${key.replace(/_/g,' ')}: ${value}\n`;
                }
                popup.innerText = infoText;

                // Show popup
                popup.style.transform = 'translate(-50%, -50%) scale(1)';
                popup.style.opacity = '1';

                // Fade out and redirect
                setTimeout(() => {
                    popup.style.opacity = '0';
                    popup.style.transform = 'translate(-50%, -50%) scale(0)';

                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 600);
                }, 4000);
            }, 800); // reduce fake network delay so loader isn't stuck
        } catch(err) {
            console.error('Form JS Error:', err);
            alert('Oops! Something went wrong. Please refresh and try again.');
        }
    });
});