/* ================================
   GLOBAL HELPERS
================================ */
const backToTopBtn = document.querySelector('.back-to-top');
const sections = document.querySelectorAll('section');
const navLinks = document.querySelectorAll('.nav-links a');

/* ================================
   BACK TO TOP BUTTON LOGIC
================================ */
window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
        backToTopBtn.style.opacity = '1';
        backToTopBtn.style.pointerEvents = 'auto';
    } else {
        backToTopBtn.style.opacity = '0';
        backToTopBtn.style.pointerEvents = 'none';
    }
});

/* ================================
   ACTIVE NAV LINK ON SCROLL
================================ */
window.addEventListener('scroll', () => {
    let current = '';

    sections.forEach(section => {
        const sectionTop = section.offsetTop - 120;
        const sectionHeight = section.offsetHeight;

        if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').includes(current)) {
            link.classList.add('active');
        }
    });
});

/* ================================
   SCROLL REVEAL ANIMATION
================================ */
const revealElements = document.querySelectorAll(
    '.card, .testimonial-card, .flyer-image, .flyer-content'
);

const revealOnScroll = () => {
    const triggerBottom = window.innerHeight * 0.85;

    revealElements.forEach(el => {
        const elementTop = el.getBoundingClientRect().top;

        if (elementTop < triggerBottom) {
            el.classList.add('reveal');
        }
    });
};

window.addEventListener('scroll', revealOnScroll);
revealOnScroll(); // run on load